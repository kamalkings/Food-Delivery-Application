package com.food.delivery.app.ws.model.response;

public enum RequestOperationName {

	DELETE
}
